/**
 * form.js
 * Three pipeline sections per design block:
 *   1. Fabric Order Details
 *   2. Embroidery Pipeline
 *   3. Stitching Pipeline
 */

var designCount   = 0;
var fabricCounters    = {};   // fabric rows per design
var embroideryCounters = {};  // embroidery rows per design
var stitchCounters    = {};   // stitching rows per design

/* ─────────────────────────────────────────
   SECTION HEADER HELPER
───────────────────────────────────────── */
function sectionHeader(icon, label, color) {
  return '<div style="' +
    'background:' + color + ';color:#fff;' +
    'padding:8px 14px;border-radius:7px 7px 0 0;' +
    'font-size:0.78rem;font-weight:700;letter-spacing:1px;text-transform:uppercase;' +
    'margin-top:20px;' +
  '">' + icon + ' ' + label + '</div>';
}

/* ─────────────────────────────────────────
   ADD DESIGN BLOCK
───────────────────────────────────────── */
function addDesign() {
  designCount++;
  var id = designCount;
  var container = document.getElementById('designs-container');

  var block = document.createElement('div');
  block.className = 'design-block';
  block.id = 'design-' + id;

  block.innerHTML =

    /* ── Top: image + header fields ── */
    '<div class="design-top">' +

      '<div class="image-upload-box">' +
        '<label class="upload-label">Design Image</label>' +
        '<div class="drop-zone" id="dropzone-' + id + '"' +
             ' ondragover="handleDragOver(event,' + id + ')"' +
             ' ondragleave="handleDragLeave(event,' + id + ')"' +
             ' ondrop="handleDrop(event,' + id + ')">' +
          '<span class="drop-icon">&#x1F4F8;</span>' +
          '<span class="drop-text">Click or drag<br>image here</span>' +
          '<input type="file" accept="image/*" id="imgfile-' + id + '"' +
                 ' onchange="handleImageSelect(this,' + id + ')" />' +
        '</div>' +
        '<button class="remove-img-btn" id="removeimg-' + id + '"' +
                ' onclick="removeImage(' + id + ')">&#x2715; Remove</button>' +
      '</div>' +

      '<div class="design-fields">' +
        '<div class="field-group">' +
          '<label>Order No.</label>' +
          '<input type="text" placeholder="Auto" id="orderno-' + id + '" readonly style="background:#f0f0f0;color:#e65100;font-weight:700;" />' +
        '</div>' +
        '<div class="field-group">' +
          '<label>D No (Design No.)</label>' +
          '<input type="text" placeholder="e.g. 3015" id="dno-' + id + '" />' +
        '</div>' +
        '<div class="field-group">' +
          '<label>Fabric Type</label>' +
          '<input type="text" placeholder="e.g. Semi Lachko" id="fabric-' + id + '" />' +
        '</div>' +
        '<div class="field-group">' +
          '<label>Order Date</label>' +
          '<input type="date" id="date-' + id + '" value="' + todayISO() + '" />' +
        '</div>' +
        '<button class="remove-design-btn" onclick="removeDesign(' + id + ')">&#x2715; Remove Design</button>' +
      '</div>' +

    '</div>' +

    /* ══════════════════════════════════
       SECTION 1 — FABRIC ORDER DETAILS
    ══════════════════════════════════ */
    sectionHeader('&#x1F9F5;', 'Fabric Order Details', '#3949ab') +
    '<div class="table-wrapper pipeline-box" style="border-color:#3949ab;">' +
      '<table id="fabric-table-' + id + '">' +
        '<thead><tr>' +
          '<th style="background:#3949ab;color:#fff">#</th>' +
          '<th style="background:#3949ab;color:#fff">Fabric Name</th>' +
          '<th style="background:#3949ab;color:#fff">Colour</th>' +
          '<th style="background:#3949ab;color:#fff">Total Fab</th>' +
          '<th style="background:#3949ab;color:#fff">Work Fab</th>' +
          '<th style="background:#3949ab;color:#fff">Plain Fab</th>' +
          '<th style="background:#3949ab;color:#fff">Work Pcs</th>' +
          '<th style="background:#3949ab;color:#fff"></th>' +
        '</tr></thead>' +
        '<tbody id="fabric-tbody-' + id + '"></tbody>' +
      '</table>' +
    '</div>' +
    '<div class="btn-row">' +
      '<button class="btn-add-row btn-add-fabric" onclick="addFabricRow(' + id + ')">+ Add Fabric Row</button>' +
    '</div>' +

    /* ══════════════════════════════════
       SECTION 2 — EMBROIDERY PIPELINE
    ══════════════════════════════════ */
    sectionHeader('&#x1FAE7;', 'Embroidery Pipeline', '#6a1b9a') +
    '<div class="table-wrapper pipeline-box" style="border-color:#6a1b9a;">' +
      '<table id="emb-table-' + id + '">' +
        '<thead>' +
          '<tr>' +
            '<th rowspan="2" style="background:#6a1b9a;color:#fff">#</th>' +
            '<th rowspan="2" style="background:#6a1b9a;color:#fff">Party Name</th>' +
            '<th rowspan="2" style="background:#6a1b9a;color:#fff">Date</th>' +
            '<th colspan="3" style="background:#4a148c;color:#fff">Work Sent (meters)</th>' +
            '<th colspan="3" style="background:#4a148c;color:#fff">Work Returned (meters)</th>' +
            '<th rowspan="2" style="background:#6a1b9a;color:#fff"></th>' +
          '</tr>' +
          '<tr>' +
            '<th style="background:#7b1fa2;color:#fff">Front</th>' +
            '<th style="background:#7b1fa2;color:#fff">Back</th>' +
            '<th style="background:#7b1fa2;color:#fff">Sleeve</th>' +
            '<th style="background:#7b1fa2;color:#fff">Front</th>' +
            '<th style="background:#7b1fa2;color:#fff">Back</th>' +
            '<th style="background:#7b1fa2;color:#fff">Sleeve</th>' +
          '</tr>' +
        '</thead>' +
        '<tbody id="emb-tbody-' + id + '"></tbody>' +
      '</table>' +
    '</div>' +
    '<div class="btn-row">' +
      '<button class="btn-add-row btn-add-emb" onclick="addEmbroideryRow(' + id + ')">+ Add Embroidery Row</button>' +
    '</div>' +

    /* ══════════════════════════════════
       SECTION 3 — STITCHING PIPELINE
    ══════════════════════════════════ */
    sectionHeader('&#x2702;&#xFE0F;', 'Stitching Pipeline', '#00695c') +
    '<div class="table-wrapper pipeline-box" style="border-color:#00695c;">' +
      '<table id="stitch-table-' + id + '">' +
        '<thead><tr>' +
          '<th style="background:#00695c;color:#fff">#</th>' +
          '<th style="background:#00695c;color:#fff">Party Name</th>' +
          '<th style="background:#00695c;color:#fff">Sent Date</th>' +
          '<th style="background:#00695c;color:#fff">Expected Pcs</th>' +
          '<th style="background:#00695c;color:#fff">Received Pcs</th>' +
          '<th style="background:#00695c;color:#fff"></th>' +
        '</tr></thead>' +
        '<tbody id="stitch-tbody-' + id + '"></tbody>' +
      '</table>' +
    '</div>' +
    '<div class="btn-row">' +
      '<button class="btn-add-row btn-add-stitch" onclick="addStitchRow(' + id + ')">+ Add Stitch Row</button>' +
    '</div>';

  container.appendChild(block);

  // 1 default row in each section
  addFabricRow(id);
  addEmbroideryRow(id);
  addStitchRow(id);
}

/* ─────────────────────────────────────────
   SECTION 1 — FABRIC ROW
───────────────────────────────────────── */
function addFabricRow(designId) {
  if (!fabricCounters[designId]) fabricCounters[designId] = 0;
  fabricCounters[designId]++;
  var rowId = fabricCounters[designId];

  var tbody = document.getElementById('fabric-tbody-' + designId);
  var tr = document.createElement('tr');
  tr.id = 'fabric-row-' + designId + '-' + rowId;
  tr.innerHTML =
    '<td>' + rowId + '</td>' +
    '<td><input type="text" placeholder="Fabric name" /></td>' +
    '<td><input type="text" placeholder="Colour - Code" /></td>' +
    '<td><input type="text" placeholder="e.g. 90" /></td>' +
    '<td><input type="text" placeholder="e.g. 49" /></td>' +
    '<td><input type="text" placeholder="e.g. 41" /></td>' +
    '<td><input type="text" placeholder="Work pcs" /></td>' +
    '<td><button class="remove-row-btn" onclick="removeRow(\'fabric-row-' + designId + '-' + rowId + '\')" title="Remove">&#x2715;</button></td>';
  tbody.appendChild(tr);
}

/* ─────────────────────────────────────────
   SECTION 2 — EMBROIDERY ROW
───────────────────────────────────────── */
function addEmbroideryRow(designId) {
  if (!embroideryCounters[designId]) embroideryCounters[designId] = 0;
  embroideryCounters[designId]++;
  var rowId = embroideryCounters[designId];

  var tbody = document.getElementById('emb-tbody-' + designId);
  var tr = document.createElement('tr');
  tr.id = 'emb-row-' + designId + '-' + rowId;
  tr.innerHTML =
    '<td>' + rowId + '</td>' +
    '<td><input type="text" placeholder="Party name" /></td>' +
    '<td><input type="date" /></td>' +
    /* Work sent */
    '<td><input type="text" placeholder="Front m" /></td>' +
    '<td><input type="text" placeholder="Back m" /></td>' +
    '<td><input type="text" placeholder="Sleeve m" /></td>' +
    /* Work returned */
    '<td><input type="text" placeholder="Front m" /></td>' +
    '<td><input type="text" placeholder="Back m" /></td>' +
    '<td><input type="text" placeholder="Sleeve m" /></td>' +
    '<td><button class="remove-row-btn" onclick="removeRow(\'emb-row-' + designId + '-' + rowId + '\')" title="Remove">&#x2715;</button></td>';
  tbody.appendChild(tr);
}

/* ─────────────────────────────────────────
   SECTION 3 — STITCHING ROW
───────────────────────────────────────── */
function addStitchRow(designId) {
  if (!stitchCounters[designId]) stitchCounters[designId] = 0;
  stitchCounters[designId]++;
  var rowId = stitchCounters[designId];

  var tbody = document.getElementById('stitch-tbody-' + designId);
  var tr = document.createElement('tr');
  tr.id = 'stitch-row-' + designId + '-' + rowId;
  tr.innerHTML =
    '<td>' + rowId + '</td>' +
    '<td><input type="text" placeholder="Party name" /></td>' +
    '<td><input type="date" /></td>' +
    '<td><input type="text" placeholder="e.g. 90" /></td>' +
    '<td><input type="text" placeholder="e.g. 85" /></td>' +
    '<td><button class="remove-row-btn" onclick="removeRow(\'stitch-row-' + designId + '-' + rowId + '\')" title="Remove">&#x2715;</button></td>';
  tbody.appendChild(tr);
}

/* ─────────────────────────────────────────
   COLLECT ALL DATA from a design block
───────────────────────────────────────── */
function collectRows(blockId) {
  var fabricRows = [];
  document.querySelectorAll('#fabric-tbody-' + blockId + ' tr').forEach(function(row) {
    var inp = row.querySelectorAll('input');
    fabricRows.push({
      fabricName : inp[0] ? inp[0].value : '',
      colour     : inp[1] ? inp[1].value : '',
      totalFab   : inp[2] ? inp[2].value : '',
      workFab    : inp[3] ? inp[3].value : '',
      plainFab   : inp[4] ? inp[4].value : '',
      workPcs    : inp[5] ? inp[5].value : ''
    });
  });

  var embRows = [];
  document.querySelectorAll('#emb-tbody-' + blockId + ' tr').forEach(function(row) {
    var inp = row.querySelectorAll('input');
    embRows.push({
      partyName    : inp[0] ? inp[0].value : '',
      date         : inp[1] ? inp[1].value : '',
      sentFront    : inp[2] ? inp[2].value : '',
      sentBack     : inp[3] ? inp[3].value : '',
      sentSleeve   : inp[4] ? inp[4].value : '',
      returnFront  : inp[5] ? inp[5].value : '',
      returnBack   : inp[6] ? inp[6].value : '',
      returnSleeve : inp[7] ? inp[7].value : ''
    });
  });

  var stitchRows = [];
  document.querySelectorAll('#stitch-tbody-' + blockId + ' tr').forEach(function(row) {
    var inp = row.querySelectorAll('input');
    stitchRows.push({
      partyName   : inp[0] ? inp[0].value : '',
      sentDate    : inp[1] ? inp[1].value : '',
      expectedPcs : inp[2] ? inp[2].value : '',
      receivedPcs : inp[3] ? inp[3].value : ''
    });
  });

  return { fabricRows: fabricRows, embRows: embRows, stitchRows: stitchRows };
}

/* ─────────────────────────────────────────
   FILL DATA back into a design block
───────────────────────────────────────── */
function fillRows(blockId, data) {
  var fabricRows = data.fabricRows || [];
  var embRows    = data.embRows    || [];
  var stitchRows = data.stitchRows || [];

  /* Fabric */
  document.getElementById('fabric-tbody-' + blockId).innerHTML = '';
  fabricCounters[blockId] = 0;
  fabricRows.forEach(function(r) {
    addFabricRow(blockId);
    var rowId = fabricCounters[blockId];
    var inp = document.getElementById('fabric-row-' + blockId + '-' + rowId).querySelectorAll('input');
    [r.fabricName, r.colour, r.totalFab, r.workFab, r.plainFab, r.workPcs]
      .forEach(function(v, i) { if (inp[i]) inp[i].value = v || ''; });
  });

  /* Embroidery */
  document.getElementById('emb-tbody-' + blockId).innerHTML = '';
  embroideryCounters[blockId] = 0;
  embRows.forEach(function(r) {
    addEmbroideryRow(blockId);
    var rowId = embroideryCounters[blockId];
    var inp = document.getElementById('emb-row-' + blockId + '-' + rowId).querySelectorAll('input');
    [r.partyName, r.date, r.sentFront, r.sentBack, r.sentSleeve,
     r.returnFront, r.returnBack, r.returnSleeve]
      .forEach(function(v, i) { if (inp[i]) inp[i].value = v || ''; });
  });

  /* Stitching */
  document.getElementById('stitch-tbody-' + blockId).innerHTML = '';
  stitchCounters[blockId] = 0;
  stitchRows.forEach(function(r) {
    addStitchRow(blockId);
    var rowId = stitchCounters[blockId];
    var inp = document.getElementById('stitch-row-' + blockId + '-' + rowId).querySelectorAll('input');
    [r.partyName, r.sentDate, r.expectedPcs, r.receivedPcs]
      .forEach(function(v, i) { if (inp[i]) inp[i].value = v || ''; });
  });
}

/* ─────────────────────────────────────────
   REMOVE HELPERS
───────────────────────────────────────── */
function removeRow(rowId) {
  var row = document.getElementById(rowId);
  if (row) row.remove();
}

function removeDesign(id) {
  var block = document.getElementById('design-' + id);
  if (block) block.remove();
}

/* ─────────────────────────────────────────
   IMAGE HELPERS
───────────────────────────────────────── */
function handleImageSelect(input, id) {
  if (input.files && input.files[0]) loadImagePreview(input.files[0], id);
}

function handleDragOver(e, id) {
  e.preventDefault();
  document.getElementById('dropzone-' + id).classList.add('dragover');
}

function handleDragLeave(e, id) {
  document.getElementById('dropzone-' + id).classList.remove('dragover');
}

function handleDrop(e, id) {
  e.preventDefault();
  document.getElementById('dropzone-' + id).classList.remove('dragover');
  var file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) loadImagePreview(file, id);
}

function loadImagePreview(file, id) {
  var reader = new FileReader();
  reader.onload = function(evt) { setDropZoneImage(id, evt.target.result); };
  reader.readAsDataURL(file);
}

function setDropZoneImage(id, src) {
  var zone = document.getElementById('dropzone-' + id);
  var existing = zone.querySelector('img.preview-img');
  if (existing) existing.remove();
  zone.querySelector('.drop-icon').style.display = 'none';
  zone.querySelector('.drop-text').style.display = 'none';
  var img = document.createElement('img');
  img.src = src;
  img.className = 'preview-img';
  img.alt = 'Design Image';
  zone.appendChild(img);
  document.getElementById('removeimg-' + id).style.display = 'inline-block';
}

function removeImage(id) {
  var zone = document.getElementById('dropzone-' + id);
  var img = zone.querySelector('img.preview-img');
  if (img) img.remove();
  zone.querySelector('.drop-icon').style.display = '';
  zone.querySelector('.drop-text').style.display = '';
  document.getElementById('imgfile-' + id).value = '';
  document.getElementById('removeimg-' + id).style.display = 'none';
}

/* ─────────────────────────────────────────
   UTILITIES
───────────────────────────────────────── */
function todayISO() {
  return new Date().toISOString().split('T')[0];
}

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function showToast(msg, color) {
  var t = document.getElementById('toast');
  t.innerHTML = msg;
  t.style.background = color || '#2e7d32';
  t.style.display = 'block';
  setTimeout(function() { t.style.display = 'none'; }, 3000);
}
